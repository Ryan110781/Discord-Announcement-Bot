import discord
import yaml
import asyncio

from discord import app_commands
from discord.ext import commands

# 讀取 TOKEN
with open("TOKEN.txt", "r", encoding="utf-8") as f:
    TOKEN = f.read().strip()

# 讀取設定檔
with open("config.yml", "r", encoding="utf-8") as f:
    config = yaml.safe_load(f)

GUILD_ID = config.get("guild_id")  # 伺服器 ID
ANNOUNCE_CHANNEL_ID = config.get("announce_channel")  # 公告頻道 ID
ADMINS = config.get("admins", [])  # 管理員列表

# 機器人設定
intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print(f"已登入 {bot.user}")
    try:
        synced = await bot.tree.sync(guild=discord.Object(id=GUILD_ID))
        print(f"已同步 {len(synced)} 個指令")
    except Exception as e:
        print(f"同步指令失敗: {e}")


@bot.tree.command(name="發送公告", description="發送公告", guild=discord.Object(id=GUILD_ID))
@app_commands.describe(title="公告標題", content="公告內容")
async def send_announcement(interaction: discord.Interaction, title: str, content: str):
    if interaction.user.id not in ADMINS:
        await interaction.response.send_message("你沒有權限使用此指令！", ephemeral=True)
        return

    announcement_format = config["announcement_format"].replace("{title}", title).replace("{content}", content)

    channel = bot.get_channel(ANNOUNCE_CHANNEL_ID)
    if channel:
        await channel.send(announcement_format)
        await interaction.response.send_message("公告已發送！", ephemeral=True)
    else:
        await interaction.response.send_message("找不到公告頻道，請檢查設定檔！", ephemeral=True)


@bot.tree.command(name="載入管理員", description="重新載入管理員列表", guild=discord.Object(id=GUILD_ID))
async def reload_admins(interaction: discord.Interaction):
    global ADMINS
    with open("config.yml", "r", encoding="utf-8") as f:
        config_data = yaml.safe_load(f)
        ADMINS = config_data.get("admins", [])

    await interaction.response.send_message("管理員列表已重新載入！", ephemeral=True)


bot.run(TOKEN)
